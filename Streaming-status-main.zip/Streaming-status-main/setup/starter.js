module.exports = {
    // Array of authentication tokens
    tk: [
        "ODc0ODk4NDIyMjMzMTc4MTQy.",   // Token 1
        "MTE5MTM4NDQ3MzM4MDU4OTYwOA"   // Token 2 (Can be deleted if not needed)
    ],

    // Import additional configuration from 'config.json'
    config: require("./config.json")
};
